package i加加;

public class intdemo {

        public static void main(String args[]){
            intdemo inc = new intdemo ();
            int i = 0;
            inc.add(i);
            i = i++;
            System.out.println(i);
        }
        void add(int i){
            i++;

        }
    }
