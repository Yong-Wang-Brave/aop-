package all.String;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class test {
    
    public static void main(String[] args){  
        String a="aaa";
        String b="aaa";
        System.out.println(a==b);

/*
        List<BigDecimal> bignumbers =new ArrayList<BigDecimal>();
        bignumbers.add(new BigDecimal());

        BigDecimal res=bignumbers.get(0);
        res=res.multiply()
*/


    }
    

}
