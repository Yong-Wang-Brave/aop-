package all.lambda2;
//定义校验接口
public interface ValidationStrategy {
boolean execute(String s );

}
