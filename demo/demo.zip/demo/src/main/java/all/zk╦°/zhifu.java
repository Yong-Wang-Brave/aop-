package all.zk锁;

public class zhifu {


    public void zhifu(){
        System.out.println(Thread.currentThread().getName()+"支付成功");
    }
}
