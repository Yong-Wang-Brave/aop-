package all.circle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Y {
    
   @Autowired
    Y y;
   public   Y(){
       
       
       System.out.println("创建y");
       
       
       
       
   };
    
    
}
