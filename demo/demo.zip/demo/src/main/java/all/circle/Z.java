package all.circle;

import org.springframework.stereotype.Component;

@Component
public class Z {

    public  int ad(){

System.out.println("逻辑方法");
        return 3;


    };}