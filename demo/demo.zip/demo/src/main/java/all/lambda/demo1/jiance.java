package all.lambda.demo1;

import all.lambda.person;

interface jiance {

    boolean jiancefangfa (person p);


}
