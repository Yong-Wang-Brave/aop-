package all.lambda;


@FunctionalInterface  //接口方法唯一的标志
interface jiekou1 {

 void doSometingshit(String s);

    //void doSometingshit(String s);

}
