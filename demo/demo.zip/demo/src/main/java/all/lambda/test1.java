package all.lambda;

public class test1 {
    
    
    
    public static void main(String[] args){  

//jiekou1与这个类联系起来就是一个完整的了
       jiekou1 shixian=s->System.out.println(s);
      System.out.println("sdsda".getBytes()); //[B@b81eda8

        //string aa="eeee";


ThreadLocal aa1 =new ThreadLocal();
    } 
    
    
}
