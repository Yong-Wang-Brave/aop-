package all.lambda.demo1;

import all.lambda.person;

public interface zhixing {


    void zhixing(person person);
}
