package all.hashmap;

import org.eclipse.jdt.internal.compiler.ast.ForeachStatement;

public class hashcode与equals {


    public static void main(String[] args){
        String A ="B";
        String B="B";
        for(int i=0;i<100;i++){


        }
        System.out.println(A.hashCode());
        System.out.println(B.hashCode());
        System.out.println(B.hashCode());
    }
}
