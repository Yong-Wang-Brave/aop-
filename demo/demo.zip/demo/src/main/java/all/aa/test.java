package all.aa;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class test {
    
    public static void main(String[] args){


        Map m=new HashMap();
        //haha
        int i = 55;
        final int i1 = 66;

        String  aa= new StringBuilder().append("a").append("b").toString();




    }

    private static void addNumber(Object o) {
    }
}
