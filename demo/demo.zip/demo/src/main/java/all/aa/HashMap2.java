package all.aa;

import java.util.HashMap;

public class HashMap2 {
      public static void main(String[] args){

System.out.println(5/3);

          HashMap<String,String>  hs =new HashMap<String,String>(13);

          hs.put("杨过","2019");

          hs.put("小龙女","2018");


      }

}
